<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="Collisions" tilewidth="12" tileheight="12" tilecount="1" columns="1">
 <image source="collision.png" width="12" height="12"/>
</tileset>
